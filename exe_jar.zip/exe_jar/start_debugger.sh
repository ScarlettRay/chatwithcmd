echo "*********************************************************"
echo "*                    Hello hacker!!!                    *"
echo "*                    Created By Ray!                    *"
echo "*********************************************************"

jre/bin/java -Djava.net.preferIPv4Stack=true -jar chatwithcmd-debugger-1.1.jar
